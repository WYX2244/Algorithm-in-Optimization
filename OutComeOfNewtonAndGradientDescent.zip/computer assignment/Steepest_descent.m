function [w, f_values, grad_norms, iterations] = Steepest_descent(X, y, tol, max_iter)
    [~, p] = size(X);
    w = zeros(p, 1);
    f_values = [];
    grad_norms = [];
    iterations = 0;
    
    while iterations < max_iter
        grad = compute_gradient(X, y, w);
        grad_norm = norm(grad);
        
        if grad_norm < tol
            break;
        end
        
        alpha = armijo(X, y, w, -grad, grad);
        
        w = w - alpha * grad;
        
        f_values = [f_values; compute_loss(X, y, w)];
        grad_norms = [grad_norms; grad_norm];
        
        iterations = iterations + 1;
    end
    
    figure;
    subplot(2, 1, 1);
    plot(1:iterations, f_values, '-.');
    title('Objective Function Value');
    xlabel('Iteration');
    ylabel('Objective Function');
    
    subplot(2, 1, 2);
    plot(1:iterations, grad_norms, '-.');
    title('Norm of Gradient');
    xlabel('Iteration');
    ylabel('Norm of Gradient');
end

function f = compute_loss(X, y, w)
    n = length(y);
    f = 0;
    for i = 1:n
        xi = X(i, :)';
        yi = y(i);
        f = f - log(1 / (1 + exp(-yi * w' * xi)));
    end
    f = f / n;
end

function grad = compute_gradient(X, y, w)
    [n, p] = size(X);
    grad = zeros(p, 1);
    for i = 1:n
        xi = X(i, :)';
        yi = y(i);
        grad = grad - (yi * xi) / (1 + exp(yi * w' * xi));
    end
    grad = grad / n;
end

function alpha = armijo(X, y, w, direction, grad)
    beta = 0.5;
    sigma = 0.01;
    alpha = 1;
    
    while compute_loss(X, y, w + alpha * direction) > ...
          compute_loss(X, y, w) + sigma * alpha * grad' * direction
        alpha = beta * alpha;
    end
end
